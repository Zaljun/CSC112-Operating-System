#include "types.h"
#include "stat.h"
#include "user.h"
#include "rand.h"

int main(void){
	printf(1,"Hello world!");
	//long max  = 10;
	//long test = random_at_most(max);
	long test = 5;
	printf(1,"\n%d\n",test);
}
